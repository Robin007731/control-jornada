
import React, { useState } from 'react';
import { WorkDay, UserSettings, Advance } from '../types';
import { getSummary, formatCurrency, getDayFinancials } from '../utils';
import { Loader2, Check, ShieldCheck, FileText, Download, Printer } from 'lucide-react';
import html2canvas from 'html2canvas';

interface ReceiptProps {
  workDays: WorkDay[];
  settings: UserSettings;
  advances: Advance[];
}

const Receipt: React.FC<ReceiptProps> = ({ workDays, settings, advances }) => {
  const [isExporting, setIsExporting] = useState(false);
  const [exported, setExported] = useState(false);
  const summary = getSummary(workDays, settings, advances);
  const hasFinancialData = settings.monthlySalary > 0;
  
  const sortedDays = [...workDays]
    .filter(d => d.status === 'complete')
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  const handleDownload = async () => {
    const element = document.getElementById('receipt-capture-area-pro');
    if (!element) return;

    setIsExporting(true);
    // Agregamos clase de preparación para captura
    element.classList.add('is-generating-report');

    try {
      // Pequeña espera para que el DOM se asiente con las nuevas dimensiones
      await new Promise(resolve => setTimeout(resolve, 400));

      const canvas = await html2canvas(element, {
        scale: 3, // Calidad retina
        backgroundColor: '#ffffff',
        logging: false,
        useCORS: true,
        allowTaint: true,
        // Forzamos las dimensiones exactas para el canvas
        width: 800,
        onclone: (clonedDoc) => {
          const clonedEl = clonedDoc.getElementById('receipt-capture-area-pro');
          if (clonedEl) {
            clonedEl.style.width = '800px';
            clonedEl.style.padding = '60px';
          }
        }
      });

      const dataUrl = canvas.toDataURL('image/png', 1.0);
      const link = document.createElement('a');
      link.download = `Reporte_${settings.workerName.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.png`;
      link.href = dataUrl;
      link.click();
      
      setExported(true);
      setTimeout(() => setExported(false), 3000);
    } catch (error) {
      console.error('Export error:', error);
    } finally {
      element.classList.remove('is-generating-report');
      setIsExporting(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in max-w-xl mx-auto pb-12">
      <div className="flex justify-between items-center px-4 sm:px-2">
        <div className="space-y-1">
          <h2 className="text-2xl font-black italic uppercase tracking-tighter text-slate-900 leading-none">Report Center</h2>
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none">Exportación de Validez Profesional</p>
        </div>
        <button 
          onClick={handleDownload}
          disabled={isExporting || sortedDays.length === 0}
          className={`flex items-center gap-3 px-6 py-4 rounded-[1.8rem] font-black text-[11px] uppercase tracking-widest shadow-2xl transition-all active:scale-95 disabled:opacity-50 ${
            exported ? 'bg-emerald-600 text-white' : 'bg-slate-900 text-white'
          }`}
        >
          {isExporting ? <Loader2 className="w-4 h-4 animate-spin" /> : exported ? <Check className="w-4 h-4" /> : <Download className="w-4 h-4 text-blue-400" />}
          {isExporting ? 'Generando...' : exported ? 'Listo' : 'Exportar'}
        </button>
      </div>

      {sortedDays.length === 0 ? (
        <div className="bg-white p-20 rounded-[3rem] border-4 border-dashed border-slate-100 text-center space-y-5 mx-4 sm:mx-0">
          <div className="bg-slate-50 w-20 h-20 rounded-[2.5rem] flex items-center justify-center mx-auto text-slate-200">
             <FileText className="w-10 h-10" />
          </div>
          <p className="text-slate-400 font-black text-[11px] uppercase tracking-widest leading-relaxed">Sin jornadas completas para<br/>generar el reporte maestro.</p>
        </div>
      ) : (
        <div className="overflow-hidden rounded-[3rem] shadow-[0_30px_80px_-20px_rgba(0,0,0,0.15)] border border-slate-100 bg-white mx-4 sm:mx-0">
          <div 
            id="receipt-capture-area-pro" 
            className="bg-white p-8 sm:p-14 text-slate-800 history-report-container"
          >
            {/* Header Profesional */}
            <div className="flex justify-between items-start border-b-[10px] border-slate-900 pb-10 mb-12">
              <div className="space-y-2.5">
                <div className="flex items-center gap-4">
                  <div className="bg-slate-900 p-2.5 rounded-xl text-white shadow-xl rotate-3"><ShieldCheck className="w-7 h-7" /></div>
                  <h1 className="text-4xl font-black italic uppercase tracking-tighter leading-none text-slate-900">Informe de Jornada</h1>
                </div>
                <p className="text-[11px] font-black text-slate-400 uppercase tracking-[0.4em]">Soberanía de Datos Laborales • Uruguay</p>
              </div>
              <div className="text-right">
                <p className="text-[10px] uppercase font-black text-slate-400 tracking-widest mb-1.5">Referencia</p>
                <div className="bg-blue-600 text-white px-5 py-2 rounded-full font-black text-[10px] uppercase tracking-tighter shadow-md">Registro Verificado</div>
              </div>
            </div>

            {/* Información del Trabajador */}
            <div className="grid grid-cols-2 gap-12 mb-14">
              <div className="space-y-8 min-w-0">
                <div className="min-w-0">
                   <p className="text-[10px] uppercase font-black text-slate-400 mb-2.5 tracking-widest">Titular</p>
                   <p className="font-black text-3xl text-slate-900 leading-none uppercase italic tracking-tighter truncate">{settings.workerName}</p>
                </div>
                <div className="min-w-0">
                   <p className="text-[10px] uppercase font-black text-slate-400 mb-2.5 tracking-widest">Organización / Lugar de Trabajo</p>
                   <p className="font-black text-lg text-slate-600 leading-none uppercase tracking-tight truncate">{settings.workplaceName || 'Empresa No Especificada'}</p>
                </div>
              </div>
              <div className="text-right space-y-8 min-w-0">
                {hasFinancialData && (
                  <div className="min-w-0">
                    <p className="text-[10px] uppercase font-black text-slate-400 mb-2.5 tracking-widest">Sueldo Base Nominal</p>
                    <p className="font-black text-3xl text-blue-600 leading-none italic tabular-nums">{formatCurrency(settings.monthlySalary)}</p>
                  </div>
                )}
                <div>
                   <p className="text-[10px] uppercase font-black text-slate-400 mb-2.5 tracking-widest">Fecha de Emisión</p>
                   <p className="font-black text-sm text-slate-500 uppercase tracking-widest tabular-nums">{new Date().toLocaleDateString('es-UY', { day: '2-digit', month: 'long', year: 'numeric' })}</p>
                </div>
              </div>
            </div>

            {/* Tabla de Registros */}
            <div className="mb-14">
               <div className="flex justify-between items-end mb-8 border-b-2 border-slate-100 pb-4">
                  <h4 className="text-[12px] font-black uppercase tracking-[0.2em] text-slate-900 italic">Desglose de Actividad Mensual</h4>
                  <div className="text-[9px] font-black text-slate-300 uppercase tracking-widest">Página 1 de 1</div>
               </div>
               
               <table className="w-full text-xs border-collapse table-fixed">
                 <thead>
                   <tr className="text-slate-400 bg-slate-50/50">
                     <th className="text-left p-4 font-black uppercase tracking-widest text-[9px] w-[20%]">Fecha</th>
                     <th className="text-center p-4 font-black uppercase tracking-widest text-[9px] w-[20%]">Tipo</th>
                     <th className="text-center p-4 font-black uppercase tracking-widest text-[9px] w-[15%]">Horas</th>
                     <th className="text-center p-4 font-black uppercase tracking-widest text-[9px] w-[15%]">Extras</th>
                     {hasFinancialData && <th className="text-right p-4 font-black uppercase tracking-widest text-[9px] w-[30%]">Bruto Estimado</th>}
                   </tr>
                 </thead>
                 <tbody className="divide-y divide-slate-100">
                   {sortedDays.map(day => {
                     const { gross, duration, extraHours } = getDayFinancials(day, summary.hourlyRate);
                     return (
                       <tr key={day.id} className="font-bold hover:bg-slate-50/30 transition-colors">
                         <td className="p-4 text-slate-700 text-[11px] tabular-nums">
                            {new Date(day.date + 'T00:00:00').toLocaleDateString('es-UY', { day: '2-digit', month: 'short' })}
                         </td>
                         <td className="p-4 text-center">
                            <span className={`text-[8px] px-3 py-1 rounded-full uppercase font-black border tracking-[0.1em] ${
                               day.type === 'work' ? 'bg-blue-50 text-blue-600 border-blue-100' :
                               day.type === 'vacation' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' :
                               'bg-slate-50 text-slate-600 border-slate-100'
                            }`}>{day.type}</span>
                         </td>
                         <td className="p-4 text-center text-slate-900 text-[11px] tabular-nums">{duration.toFixed(1)}h</td>
                         <td className="p-4 text-center text-blue-600 text-[11px] tabular-nums">{extraHours > 0 ? `+${extraHours.toFixed(1)}` : '—'}</td>
                         {hasFinancialData && <td className="p-4 text-right text-slate-900 text-[11px] tabular-nums">{formatCurrency(gross)}</td>}
                       </tr>
                     );
                   })}
                 </tbody>
               </table>
            </div>

            {/* Resumen Financiero Estilo Recibo de Sueldo */}
            {hasFinancialData ? (
              <div className="space-y-8 bg-slate-900 text-white p-10 rounded-[3rem] shadow-2xl relative overflow-hidden border-t-[12px] border-blue-600">
                <div className="absolute top-0 right-0 p-8 opacity-[0.03] rotate-12">
                   <ShieldCheck className="w-48 h-48" />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-y-4 gap-x-16 relative z-10">
                   <div className="flex justify-between items-center text-sm border-b border-white/10 pb-3">
                     <span className="font-black uppercase tracking-[0.2em] text-[10px] opacity-50">Suma de Haberes Brutos</span>
                     <span className="font-black tabular-nums text-base">{formatCurrency(summary.totalGross)}</span>
                   </div>
                   <div className="flex justify-between items-center text-sm border-b border-white/10 pb-3">
                     <span className="font-black uppercase tracking-[0.2em] text-[10px] text-rose-400">Montepío / Ley (22%)</span>
                     <span className="font-black text-rose-400 tabular-nums text-base">-{formatCurrency(summary.bpsDiscount)}</span>
                   </div>
                   {summary.totalAdvances > 0 && (
                     <div className="flex justify-between items-center text-sm border-b border-white/10 pb-3">
                       <span className="font-black uppercase tracking-[0.2em] text-[10px] text-amber-400">Adelantos Percibidos</span>
                       <span className="font-black text-amber-400 tabular-nums text-base">-{formatCurrency(summary.totalAdvances)}</span>
                     </div>
                   )}
                   <div className="flex justify-between items-center text-sm border-b border-white/10 pb-3">
                     <span className="font-black uppercase tracking-[0.2em] text-[10px] text-emerald-400">Viáticos y Otros No Gravados</span>
                     <span className="font-black text-emerald-400 tabular-nums text-base">+{formatCurrency(summary.totalAllowances)}</span>
                   </div>
                </div>
                
                <div className="flex justify-between items-end pt-12 mt-6 border-t border-white/5">
                  <div className="space-y-1">
                    <p className="font-black text-blue-400 uppercase tracking-[0.5em] text-[11px] italic">Neto Líquido a Cobrar</p>
                    <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">Cálculo basado en normativa laboral general</p>
                  </div>
                  <span className="text-6xl font-black italic tracking-tighter leading-none text-white tabular-nums drop-shadow-lg">{formatCurrency(summary.netPay)}</span>
                </div>
              </div>
            ) : (
              <div className="bg-slate-50 p-12 rounded-[3rem] text-center border-2 border-dashed border-slate-200">
                 <p className="text-[11px] font-black uppercase text-slate-400 tracking-[0.3em] mb-3">Total de Horas Computadas</p>
                 <p className="text-6xl font-black italic text-slate-900 tabular-nums">
                    {(summary.totalNormalHours + summary.totalExtraHours).toFixed(1)} 
                    <span className="text-2xl ml-2 text-blue-600">Horas</span>
                 </p>
              </div>
            )}

            {/* Footer de Validez */}
            <div className="mt-16 pt-10 border-t-2 border-slate-50 flex justify-between items-center opacity-40">
              <div className="flex items-center gap-4">
                 <div className="w-10 h-10 border-2 border-slate-900 rounded-lg flex items-center justify-center font-black text-xs italic">LLV</div>
                 <div className="space-y-0.5">
                    <p className="text-[10px] font-black text-slate-900 uppercase">Sistema de Registro Autónomo</p>
                    <p className="text-[8px] font-bold text-slate-500 uppercase tracking-widest">Reporte Generado por Aplicación Local</p>
                 </div>
              </div>
              <div className="text-right">
                <p className="text-[9px] font-black uppercase tracking-widest text-slate-400 mb-1">Cálculo Uruguay v5.5</p>
                <p className="text-[7px] font-bold text-slate-300 uppercase tracking-[0.2em]">Sujeto a validación por RRHH</p>
              </div>
            </div>
          </div>
        </div>
      )}

      <style>{`
        .is-generating-report {
          width: 800px !important;
          max-width: 800px !important;
          margin: 0 !important;
          padding: 60px !important;
          border: none !important;
          border-radius: 0 !important;
          box-shadow: none !important;
        }
        .is-generating-report table {
          table-layout: fixed !important;
        }
        .is-generating-report .tabular-nums {
          font-variant-numeric: tabular-nums !important;
          letter-spacing: -0.05em !important;
        }
        .is-generating-report h1, .is-generating-report p, .is-generating-report span {
          -webkit-font-smoothing: antialiased !important;
        }
      `}</style>
    </div>
  );
};

export default Receipt;
